﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Forms;
using SimpleTCP;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.IO;

namespace Serverclient
{
    public partial class Serverclientside : Form
    {
        SpotifyAPI api = new SpotifyAPI("BQBgF8gTGUH-TIVTTLU0Xz5bphE5t4FAliIRe696zzuf6U9tpw0STMev0i_fyJWolo-tiEu6VsslLDG4HVmoHyMRaWsnjwwj9J-EOm6xvBIbIq_0Qu_SvS4-X0tOCd94k2uRk4d4");
        double BPM;
        double Artiest;
        double Track;
        double Energie;
        double DanceAbility;

        public Serverclientside()
        {
            InitializeComponent();
        }

        SimpleTcpClient client;

        private void Serverclientside_Load(object sender, EventArgs e)
        {
            // simpletcp setup
            client = new SimpleTcpClient();
            client.StringEncoder = Encoding.UTF8;
            client.DataReceived += Client_DataReceived;
        }

        //   private void Jsonloading()
        //   {
        //       using (System.IO.StreamReader r = new System.IO.StreamReader(src))
        //       {
        //           string json = r.ReadToEnd();
        //           Muziekinfo item = Newtonsoft.Json.JsonConvert.DeserializeObject<Muziekinfo>(json);
        //       }
        //   }
        private void TbHost_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtConnect_Click(object sender, EventArgs e)
        {
            btConnect.Enabled = false;
            //Connect to server
            client.Connect(tbHost.Text, Convert.ToInt32(tbPort.Text));
        }

        private void Client_DataReceived(object sender, SimpleTCP.Message e)
        {
            //Update message to tbStatus
            tbStatus.Invoke((MethodInvoker)delegate ()
            {
                tbStatus.Text += e.MessageString;
            });
        }
        private void BtSend_Click(object sender, EventArgs e)
        {
            // message check when clicking the button
            client.WriteLineAndGetReply(tbMessage.Text, TimeSpan.FromSeconds(3));
        }

        private void TbStatus_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            lbBPM.Text = api.getData("bpm");
            lbArtist.Text = api.getData("artist");
            lbTrack.Text = api.getData("track");
            lbEnergy.Text = api.getData("energy");
            lbDance.Text = api.getData("danceability");
        }

        private void lichteffecten()
        {
            BPM = api.getData("bpm");
            Artiest = api.getData("artist");
            Track = api.getData("track");
            Energie = api.getData("energy");
            DanceAbility = api.getData("danceability");

            if (BPM <= 170
                { })
        }
    }
}
