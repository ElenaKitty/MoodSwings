﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Serverclient
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            string filepath = @"..\..\..\Resources\CurrentTrack.json";
            SpotifyAPI spotify = new SpotifyAPI("BQBgF8gTGUH-TIVTTLU0Xz5bphE5t4FAliIRe696zzuf6U9tpw0STMev0i_fyJWolo-tiEu6VsslLDG4HVmoHyMRaWsnjwwj9J-EOm6xvBIbIq_0Qu_SvS4-X0tOCd94k2uRk4d4");
            spotify.getCurrentTrack();
            spotify.getTrackFeatures(filepath);
            spotify.getTrackAnalysis(filepath);

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Serverclientside());
        }
    }
}
